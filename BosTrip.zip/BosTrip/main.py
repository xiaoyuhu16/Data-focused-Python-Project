# Name: Xiaoyu Hu, Yang Wang, Han Bao, Zhenyi Wei, Wei Zou
# Andrew ID: xiaoyuhu, yangwan4, hanb, zhenyiw, weizou
# This main.py utilizes files generated from data_processing.py to run in GUI

import tkinter as tk
import pandas as pd
from tkinter import messagebox
import webbrowser  # this will show in browser
import data_processing

pd.set_option('display.max_columns', None)


class App(tk.Tk):
    def __init__(self):
        super().__init__()

        self.title('Welcome to use BosTrip')
        self.geometry('700x600')  # the size of gui

        self.frames = {}
        for F in (WelcomePage1, WelcomePage2, HotelPage, PreferencePage, BudgetPage, ResultPage, VisualizationPage):
            frame = F(parent=self, controller=self)
            self.frames[F] = frame
            frame.grid(row=0, column=0, sticky="nsew")

        self.show_frame(WelcomePage1)

    def show_frame(self, page_name):
        frame = self.frames[page_name]
        frame.tkraise()

    def download_data(self):
        # Call the download_data function from data_processing module
        data_processing.download_new_data()
        # Proceed to the HotelPage or any other appropriate page
        self.show_frame(WelcomePage2)

    def use_downloaded_data(self):
        # Call the use_downloaded function from data_processing module
        data_processing.use_processed_data()
        # Proceed to the HotelPage or any other appropriate page
        self.show_frame(WelcomePage2)


# download data page
class WelcomePage1(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller

        self.label = tk.Label(self, text="Welcome to use BosTrip", font=("Arial", 20))
        self.label.pack(pady=40)

        # Button to download data
        self.download_button = tk.Button(self, text="Download New Data \n (Warning: Takes up to 2 hours)",
                                         command=controller.download_data)
        self.download_button.pack(pady=20)

        # Button to use previously downloaded data
        self.use_downloaded_button = tk.Button(self, text="Use Previously Downloaded Data",
                                               command=controller.use_downloaded_data)
        self.use_downloaded_button.pack(pady=20)


# main menu
class WelcomePage2(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller

        self.label = tk.Label(self, text="Welcome to use BosTrip", font=("Arial", 20))
        self.label.pack(pady=40)

        self.hotel_button = tk.Button(self, text="Hotel Recommendation App",
                                      command=lambda: controller.show_frame(HotelPage))
        self.hotel_button.pack(pady=20)

        self.visualization_button = tk.Button(self, text="Visualizations of features",
                                              command=lambda: controller.show_frame(VisualizationPage))
        self.visualization_button.pack(pady=20)

        self.return_button = tk.Button(self, text="Return to download data page",
                                       command=lambda: controller.show_frame(WelcomePage1))
        self.return_button.pack(pady=20)

        self.quit_button = tk.Button(self, text="Quit", command=controller.quit)
        self.quit_button.pack(pady=20)


# hotel page
class HotelPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller

        self.label = tk.Label(self,
                              text="Do you have preference for number of \n\n Restaurant/Crime Records/Transportation in your region?",
                              font=("Arial", 20))
        self.label.pack(pady=40)

        self.preference_button = tk.Button(self, text="Preference",
                                           command=lambda: controller.show_frame(PreferencePage))
        self.preference_button.pack(pady=10)

        self.no_preference_button = tk.Button(self, text="No Preference",
                                              command=lambda: controller.show_frame(BudgetPage))
        self.no_preference_button.pack(pady=10)

        self.return_button = tk.Button(self, text="Return", command=lambda: controller.show_frame(WelcomePage2))
        self.return_button.pack(pady=10)


# priority of factors
class PreferencePage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller

        self.label = tk.Label(self,
                              text="\n\n\nPlease rank the following factors in order of priority (for example: 312):",
                              font=("Arial", 12))
        self.label.pack(pady=10)

        self.factor_labels = [
            "1. Number of restaurants",
            "2. Number of crimes",
            "3. Transportation convenience"
        ]

        # Display the factor labels
        for label_text in self.factor_labels:
            factor_label = tk.Label(self, text=label_text)
            factor_label.pack()

        self.preference_entry = tk.Entry(self)
        self.preference_entry.pack(pady=10)

        self.submit_button = tk.Button(self, text="Submit", command=self.validate_and_submit)
        self.submit_button.pack(pady=10)  # command=lambda: controller.show_frame(BudgetPage))

        self.return_button = tk.Button(self, text="Return", command=lambda: controller.show_frame(HotelPage))
        self.return_button.pack(pady=10)

    def validate_and_submit(self):
        preference_input = self.preference_entry.get()

        # Check if the input is a valid ordering of 1, 2, and 3
        if set(preference_input) == {'1', '2', '3'} and len(preference_input) == 3:
            # The input is valid, proceed to the BudgetPage
            self.controller.show_frame(BudgetPage)
        else:
            messagebox.showerror("Invalid Input", "Please enter a valid ordering of 1, 2, and 3 (e.g., 312).")


# desirable price range of hotels
def is_valid_price(price):
    try:
        price = float(price)
        return price >= 0
    except ValueError:
        return False


class BudgetPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller

        self.label = tk.Label(self, text="\n\n\nEnter your acceptable price range (USD):", font=("Arial", 12))
        self.label.pack(pady=10)

        self.min_price_label = tk.Label(self, text="Minimum price:")
        self.min_price_label.pack()

        self.min_price_entry = tk.Entry(self)
        self.min_price_entry.pack(pady=5)

        self.max_price_label = tk.Label(self, text="Maximum price:")
        self.max_price_label.pack()

        self.max_price_entry = tk.Entry(self)
        self.max_price_entry.pack(pady=5)

        self.submit_button = tk.Button(self, text="Submit", command=self.validate_and_submit)
        self.submit_button.pack(pady=10)  # command=lambda: controller.show_frame(ResultPage))

        self.return_button = tk.Button(self, text="Return", command=lambda: controller.show_frame(
            PreferencePage if controller.frames[PreferencePage].winfo_viewable() else HotelPage))
        self.return_button.pack(pady=10)

    def validate_and_submit(self):
        min_price = self.min_price_entry.get()
        max_price = self.max_price_entry.get()

        # Check if both min_price and max_price are valid positive numbers
        if is_valid_price(min_price) and is_valid_price(max_price):
            min_price = float(min_price)
            max_price = float(max_price)

            # Check if min_price is less than or equal to max_price
            if min_price <= max_price:
                # The input is valid, proceed to the ResultPage
                self.controller.frames[ResultPage].show_recommendations()
                self.controller.show_frame(ResultPage)
            else:
                messagebox.showerror("Invalid Input", "Minimum price cannot be greater than maximum price.")
        else:
            messagebox.showerror("Invalid Input",
                                 "Please enter valid positive numbers for both minimum and maximum prices.")


# Show the recommendation results here
class ResultPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller

        self.best_zip_label = tk.Label(self, text="\n\n\nBest zip code to live based on your preferences:")
        self.best_zip_label.pack(pady=10)

        self.best_zip_value = tk.Label(self, text="", font=("Arial", 12, "bold"))
        self.best_zip_value.pack(pady=10)

        self.recommended_label = tk.Label(self, text="Here are our recommended hotels in the area:")
        self.recommended_label.pack(pady=5)

        self.recommended_hotels = tk.Text(self, height=10, width=100)
        self.recommended_hotels.pack(pady=10)

        self.main_menu_button = tk.Button(self, text="Main Menu", command=lambda: controller.show_frame(WelcomePage2))
        self.main_menu_button.pack(pady=10)

        self.return_button = tk.Button(self, text="Return", command=lambda: controller.show_frame(BudgetPage))
        self.return_button.pack(pady=10)

        self.quit_button = tk.Button(self, text="Quit", command=controller.quit)
        self.quit_button.pack(pady=10)

    # Function to calculate scores and show recommendations
    def calculate_and_show_recommendations(self):
        # best_zip, data = self.calculate_scores()
        self.show_recommendations()

    # rank the zip codes
    def calculate_scores(self):
        data = pd.read_csv("normalized_zipcode.csv", dtype={"zipcode": str})

        # Calculate scores based on user's preferences or average if no preference
        user_preference = self.controller.frames[PreferencePage].preference_entry.get()
        if user_preference:
            weights = [0.6, 0.3, 0.1]  # Default weights if not specified in preference

            # Calculate weights based on the user's preference order
            weights = [weights[int(user_preference.index(str(i + 1)))] for i in range(3)]
        else:
            weights = [1 / 3, 1 / 3, 1 / 3]  # Equal weights for no preference

        data["score"] = data["restaurants_per_area"] * weights[0] + data["cases_per_area"] * weights[1] + data[
            "transportation_per_area"] * weights[2]

        # Find the best zip code with the highest score
        best_zip = data.loc[data["score"].idxmax()]

        return best_zip
        # return best_zip, data  # return data is not necessary in this case, just for your debugging

    # given best zip code, price range and ratings, find the recommended hotels
    def show_recommendations(self):
        # print('show recom')
        min_price = float(self.controller.frames[BudgetPage].min_price_entry.get())
        max_price = float(self.controller.frames[BudgetPage].max_price_entry.get())

        # best_zip, data = self.calculate_scores()  # data is not necessary in this case, just for your debugging
        best_zip = self.calculate_scores()
        best_zip_code = best_zip["zipcode"]
        # Read hotels data
        hotels_data = pd.read_csv("hotels.csv", dtype=str)
        hotels_data.columns = ['hotel_name', 'Distance', 'Address', 'zipcode', 'longitude', 'latitude',
                               'longitude2', 'latitude2', 'rating', 'price', 'other', 'website']
        # print(hotels_data['zipcode'].str[4:9])
        # print(best_zip_code)
        recommended_hotels = hotels_data[hotels_data['zipcode'].str[4:9] == best_zip_code]
        # print(recommended_hotels)
        recommended_hotels['price'] = pd.to_numeric(recommended_hotels['price'], errors='coerce')
        recommended_hotels = recommended_hotels[(recommended_hotels['price'] > min_price)
                                                & (recommended_hotels['price'] < max_price)]

        self.best_zip_value.config(text=str(best_zip_code))
        self.recommended_hotels.delete('1.0', tk.END)
        for _, row in recommended_hotels.iterrows():
            self.recommended_hotels.insert(tk.END,
                                           f" Hotel name: {row['hotel_name']}\n Address: {row['Address']} Price: ${row['price']}/night\n Rating: {row['rating']}\n Link: {row['website']}\n\n\n")

        self.best_zip_label.pack()
        self.best_zip_value.pack()
        self.recommended_label.pack()
        self.recommended_hotels.pack()


# Have a look at the maps
class VisualizationPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller

        self.label = tk.Label(self, text="Choose a Map:", font=("Arial", 20))
        self.label.pack(pady=20)

        self.map_choice_label = tk.Label(self,
                                         text="Enter 1 for Restaurant Map, 2 for Crime Map, 3 for Transportation Map:")
        self.map_choice_label.pack(pady=10)

        self.map_choice_entry = tk.Entry(self)
        self.map_choice_entry.pack(pady=10)

        self.show_map_button = tk.Button(self, text="Show Map", command=self.show_selected_map)
        self.show_map_button.pack(pady=10)

        self.return_button = tk.Button(self, text="Return", command=lambda: controller.show_frame(WelcomePage2))
        self.return_button.pack(pady=10)

    def show_selected_map(self):
        map_choice = self.map_choice_entry.get()

        if map_choice not in ['1', '2', '3']:
            messagebox.showerror("Invalid Input", "Please enter a valid choice (1, 2, or 3).")
            return

        map_filename = ""
        if map_choice == '1':
            map_filename = "boston_restaurants.html"
        elif map_choice == '2':
            map_filename = "boston_crimes_heatmap.html"
        elif map_choice == '3':
            map_filename = "boston_transport_map.html"

        # Open the selected map in the default web browser
        webbrowser.open(map_filename)

        # Load the selected map in the WebView
        # self.webview.load_url(f"file://{map_filename}")  # use this one instead if don't want to be in browser!

        self.return_button.pack(pady=10)


# this program is the main program
if __name__ == "__main__":
    app = App()
    app.mainloop()
