# Name: Xiaoyu Hu, Yang Wang, Han Bao, Zhenyi Wei, Wei Zou
# Andrew ID: xiaoyuhu, yangwan4, hanb, zhenyiw, weizou
# This visualization module is imported in data_processing.py

import pandas as pd
import folium
import json
from folium.plugins import HeatMap


def create_crime_visualization():
    # Load the data from the CSV file
    df = pd.read_csv("crime_incident_data_with_zipcode.csv")
    df = df.dropna(subset=['Lat', 'Long'])

    # Create a base map centered around Boston
    m = folium.Map(location=[42.3601, -71.0589], zoom_start=13)

    # Prepare heatmap data
    heat_data = [[row['Lat'], row['Long'], row['Number_Of_Cases']] for _, row in df.iterrows()]

    # Add the heatmap to the map
    HeatMap(heat_data, radius=20, max_zoom=13, blur=15, max_val=float(df['Number_Of_Cases'].max())).add_to(m)

    # Add ZIP code boundaries to the map
    geojson_path = "boston_zipcodes.geojson"
    with open(geojson_path, 'r') as file:
        zipcodes_geojson = json.load(file)

    folium.GeoJson(
        zipcodes_geojson,
        name='ZIP Code Boundaries',
        style_function=lambda x: {
            'fillColor': 'transparent',
            'color': 'blue',
            'weight': 1.5,
            'fillOpacity': 0
        }
    ).add_to(m)

    # Save the map to an HTML file
    m.save("boston_crimes_heatmap.html")
