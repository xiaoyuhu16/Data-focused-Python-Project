# Name: Xiaoyu Hu, Yang Wang, Han Bao, Zhenyi Wei, Wei Zou
# Andrew ID: xiaoyuhu, yangwan4, hanb, zhenyiw, weizou
# This scrapeRestaurants.py is imported in data_processing.py

import csv
import json


def cleanName(name):
    res = ""
    for char in name:
        if ' ' <= char <= '~':
            res += char
    return res


def extractRR(file):
    text = open(file, "r", encoding="utf-8").read()
    rrs = json.loads(eval(text))['multiSearch']['restaurants']
    res = []
    for rr in rrs:
        name = cleanName(rr["name"])
        # type_ = rr["type"]
        type_ = rr['diningStyle']
        recentrsv = rr['statistics']['recentReservationCount']
        link = rr["urls"]["profileLink"]["link"]
        priceband = rr["priceBand"]["currencySymbol"] * rr["priceBand"]["priceBandId"]
        neighborhood = rr["neighborhood"]["name"]
        rating = rr["statistics"]["reviews"]["ratings"]["overall"]["rating"]
        cuisine = rr["primaryCuisine"]["name"]
        latitude = rr["coordinates"]["latitude"]
        longtitude = rr["coordinates"]["longitude"]
        address = str(rr["address"]['line1']) + str(rr['address']['line2'])
        postcode = 'MA ' + str(rr["address"]["postCode"])[:5]
        # des = rr["description"]
        contact = rr["contactInformation"]["formattedPhoneNumber"][:14]

        res.append(
            [name, type_, recentrsv, link, priceband, neighborhood, rating, cuisine, latitude, longtitude, address,
             postcode, contact])

    return res


def extractSinglePage():
    output = csv.writer(open("restaurants.csv", "w", encoding="utf-8", newline=""))
    for i in range(1, 13):
        res = extractRR("restaurants/{}.txt".format(i))
        for info in res:
            output.writerow(info)


# if __name__ == "__main__":
#     extractSinglePage()
