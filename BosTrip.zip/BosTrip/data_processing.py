# Name: Xiaoyu Hu, Yang Wang, Han Bao, Zhenyi Wei, Wei Zou
# Andrew ID: xiaoyuhu, yangwan4, hanb, zhenyiw, weizou
# This data_processing.py downloads and processed all the datasets needed for the project

import requests
import pandas as pd
import json
import geopy
from bs4 import BeautifulSoup
import geopandas as gpd
import csv
from io import StringIO

# This data_processing.py imports other modules that scrapes hotel and restaurant data
# and modules that create visualizations for crimes, restaurants, and transportation.
import scrapeHotel
import scrapeRestaurants
import visualize_crimes
import visualize_restaurants
import visualize_Transportation


pd.set_option('display.max_columns', None)


def download_data():
    # CRIME RECORD DATA DOWNLOAD
    url = 'https://data.boston.gov/dataset/crime-incident-reports-august-2015-to-date-source-new-system'
    resp = requests.get(url)
    soup = BeautifulSoup(resp.text, "lxml")
    target = soup.find_all("script", type="application/ld+json")[0]
    targetJson = json.loads("\n".join(str(target).split("\n")[1:-1]))
    csvurl = "schema:url"
    for info in targetJson['@graph']:
        if "schema:name" in info and "2022" in info["schema:name"]:
            csvurl = info["schema:url"]
    url = csvurl
    response = requests.get(url)
    if response.status_code == 200:
        with open('crime_incident_data.csv', 'wb') as file:
            file.write(response.content)
        print("successfully downloaded crime data")
    else:
        print(f'Failed to download crime CSV file. Status code: {response.status_code}')

    # TRANSPORTATION - BIKE DOWNLOAD
    url = 'https://s3.amazonaws.com/hubway-data/current_bluebikes_stations.csv'
    response = requests.get(url)
    if response.status_code == 200:
        with open('bike_data.csv', 'wb') as file:
            file.write(response.content)
        print("successfully downloaded bike data")
    else:
        print(f'Failed to download bike CSV file. Status code: {response.status_code}')

    # TRANSPORTATION - BUS DOWNLOAD
    url = 'https://opendata.arcgis.com/api/v3/datasets/55586c8f54954f8e8fae5f40cb953d15_0/downloads/data?format=geojson&spatialRefId=4326&where=1%3D1'
    response = requests.get(url)
    if response.status_code == 200:
        json_data = json.loads(response.text)
        txt_file_path = 'bus_data.txt'

        with open(txt_file_path, 'w') as txt_file:
            for item in json_data.get('features', []):
                feature_data = {
                    'attributes': item.get('properties', {}),
                    'geometry': item.get('geometry', {})
                }
                json_line = json.dumps(feature_data)
                txt_file.write(json_line + '\n')
        print("successfully downloaded bus data")
    else:
        print(f'Failed to download bus json file. Status code: {response.status_code}')

    # Zipcode - Zipcode Download
    url = "https://bostonopendata-boston.opendata.arcgis.com/datasets/boston::zip-codes.geojson?where=1=1&outSR=%7B%22latestWkid%22%3A2249%2C%22wkid%22%3A102686%7D"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        gdf_zipcode = gpd.read_file(StringIO(response.text))
        output_file_path = "boston_zipcodes.geojson"
        gdf_zipcode.to_file(output_file_path, driver="GeoJSON")
        print(f"GeoJSON file saved as {output_file_path}")
    else:
        print(f"Failed to fetch the GeoJSON file. Status code: {response.status_code}")

    url = "https://bostonopendata-boston.opendata.arcgis.com/datasets/boston::zip-codes.csv?where=1=1&outSR=%7B%22latestWkid%22%3A2249%2C%22wkid%22%3A102686%7D"
    response = requests.get(url)
    if response.status_code == 200:
        with open('ZIP_Codes.csv', 'wb') as file:
            file.write(response.content)
        print("successfully downloaded zipcode data")
    else:
        print(f'Failed to download crime CSV file. Status code: {response.status_code}')

    # ScrapeHotel
    scrapeHotel.getList("hotels.csv")

    # ScrapeRestaurant
    scrapeRestaurants.extractSinglePage()


def load_bus(file_name):
    bus_raw = []
    with open(file_name, "r", encoding='utf-8') as f:
        for line in f:
            try:
                json_data = json.loads(line)
                attributes = json_data['attributes']
                geometry = json_data['geometry']
                data = {
                    'OBJECT_ID': attributes['OBJECTID'],
                    'STOP_NAME': attributes['STOP_NAME'],
                    'TOWN': attributes['TOWN'],
                    'TOWN_ID': attributes['TOWN_ID'],
                    'coordinates': geometry['coordinates']
                }
                bus_raw.append(data)
            except json.JSONDecodeError:
                pass

    # Create a Pandas DataFrame from the list of dictionaries
    bus = pd.DataFrame(bus_raw)
    bus = bus[bus['TOWN'] == 'BOSTON']
    bus['Latitude'] = bus['coordinates'].apply(lambda x: x[1] if isinstance(x, list) and len(x) >= 2 else None)
    bus['Longitude'] = bus['coordinates'].apply(lambda x: x[0] if isinstance(x, list) and len(x) >= 1 else None)
    return bus


def load_crime(file_name):
    crime_raw = pd.read_csv(file_name, dtype={'INCIDENT_NUMBER': str})
    crime = crime_raw[["INCIDENT_NUMBER", "OFFENSE_DESCRIPTION", "Lat", "Long"]]
    crime = crime.dropna()
    crime['Lat'] = pd.to_numeric(crime['Lat'])
    crime['Long'] = pd.to_numeric(crime['Long'])
    crime = crime.groupby(['Lat', 'Long']).size().reset_index(name='Number_Of_Cases')
    return crime


def load_bike(file_name):
    bike_raw = pd.read_csv(file_name, skiprows=1)
    bike = bike_raw[bike_raw['District'] == 'Boston']
    bike = bike[["Number", "Total docks", "Latitude", "Longitude"]]
    bike['Latitude'] = pd.to_numeric(bike['Latitude'])
    bike['Longitude'] = pd.to_numeric(bike['Longitude'])
    return bike


def get_zipcode(df, lat_field, lon_field):
    geolocator = geopy.Nominatim(user_agent='xiaoyuhu', timeout=10000)
    location = geolocator.reverse("{}, {}".format(df[lat_field], df[lon_field]))
    try:
        return location.raw['address']['postcode']
    except Exception as e:
        return ''


def write_crime_zipcode(crime_data):
    for index, row in crime_data.iterrows():
        # Get the zipcode using the get_zipcode function
        zipcode = get_zipcode(row, 'Lat', 'Long')
        # Append the zipcode to the list
        try:
            crime_data.loc[index, 'zipcode'] = zipcode
        except Exception as e:
            crime_data.loc[index, 'zipcode'] = ''

        print("row", index, crime_data.loc[index, ['Lat', 'Long']], "\n   zipcode is ", zipcode)
    crime_data.to_csv("crime_incident_data_with_zipcode.csv")
    return crime_data


def write_bus_zipcode(bus_data):
    for index, row in bus_data.iterrows():
        # Get the zipcode using the get_zipcode function
        zipcode = get_zipcode(row, 'Latitude', 'Longitude')
        # Append the zipcode to the list
        try:
            bus_data.loc[index, 'zipcode'] = zipcode
        except Exception as e:
            bus_data.loc[index, 'zipcode'] = ''

        print("row", index, bus_data.loc[index, ["OBJECT_ID", 'Latitude', 'Longitude']], "\n   zipcode is ", zipcode)
    bus_data.to_csv("bus_data_with_zipcode.csv")
    return bus_data


def write_bike_zipcode(bike_data):
    for index, row in bike_data.iterrows():
        # Get the zipcode using the get_zipcode function
        zipcode = get_zipcode(row, 'Latitude', 'Longitude')
        # Append the zipcode to the list
        try:
            bike_data.loc[index, 'zipcode'] = zipcode
        except Exception as e:
            bike_data.loc[index, 'zipcode'] = ''

        print("row", index, bike_data.loc[index, ['Latitude', 'Longitude']], "\n   zipcode is ", zipcode)
    bike_data.to_csv("bike_data_with_zipcode.csv")
    return bike_data


def aggregate_zipcode(crime_dataset, bus_dataset, bike_dataset):
    crime_dataset = crime_dataset.dropna()
    bus_dataset = bus_dataset.dropna()
    bike_dataset = bike_dataset.dropna()
    res = {}
    rrs = csv.reader(open("restaurants.csv", "r", encoding="utf-8"))
    for row in rrs:
        zc = row[11].replace("MA ", "")
        if zc in res:
            res[zc] += 1
        else:
            res[zc] = 1
    restaurant_dataset = pd.DataFrame(list(res.items()), columns=['zipcode', 'Number_Of_Restaurant'])

    count_crime = crime_dataset.groupby('zipcode')['Number_Of_Cases'].sum().reset_index()
    count_bus = bus_dataset.groupby('zipcode').size().reset_index(name="Number_Of_Bus_Stations")
    count_bike = bike_dataset.groupby('zipcode')['Total docks'].sum().reset_index(name="Number_Of_Total_Bike_Docks")

    combined_zipcode = count_crime.merge(count_bus, on='zipcode', how='outer') \
        .merge(count_bike, on='zipcode', how='outer') \
        .merge(restaurant_dataset, on='zipcode', how='left')
    combined_zipcode = combined_zipcode.fillna(0)

    zip_code = pd.read_csv("ZIP_Codes.csv", dtype={'ZIP5': str})
    filtered_combined_zipcode = combined_zipcode[combined_zipcode['zipcode'].isin(zip_code['ZIP5'])]
    # filtered_combined_zipcode.to_csv("Info_based_on_zipcode.csv")
    return filtered_combined_zipcode


def compute_metrics_per_area(geojson_path, cases_df):
    gdf = gpd.read_file(geojson_path)
    area_df = pd.DataFrame({
        'zipcode': gdf['ZIP5'].astype(str),
        'area': gdf['ShapeSTArea']
    })

    # Merge the two DataFrames based on the ZIP code
    merged_df = pd.merge(area_df, cases_df, on='zipcode', how='inner')

    # Compute metrics per area
    # Compute metrics per area
    merged_df['cases_per_area'] = merged_df['Number_Of_Cases'] / merged_df['area']
    merged_df['bus_stations_per_area'] = merged_df['Number_Of_Bus_Stations'] / merged_df['area']
    merged_df['bike_docks_per_area'] = merged_df['Number_Of_Total_Bike_Docks'] / merged_df['area']
    merged_df['restaurants_per_area'] = merged_df['Number_Of_Restaurant'] / merged_df['area']

    return merged_df[
        ['zipcode', 'cases_per_area', 'bus_stations_per_area', 'bike_docks_per_area', 'restaurants_per_area']]


def normalize_dataframe(df):
    # Get the top 3 max values of 'cases_per_area'
    top_3_values = df['cases_per_area'].nlargest(3).tolist()

    # Omit rows with the top 3 max values of 'cases_per_area'
    df = df[~df['cases_per_area'].isin(top_3_values)]

    # Omit rows where bike, bus and restaurant are zero
    df = df[df['bike_docks_per_area'] != 0]
    df = df[df['bus_stations_per_area'] != 0]
    df = df[df['restaurants_per_area'] != 0]

    df['cases_per_area'] = (-1) * (df['cases_per_area'] - df['cases_per_area'].min()) / (
            df['cases_per_area'].max() - df['cases_per_area'].min())
    df['bus_stations_per_area'] = (df['bus_stations_per_area'] - df[
        'bus_stations_per_area'].min()) / (df['bus_stations_per_area'].max() - df['bus_stations_per_area'].min())
    df['bike_docks_per_area'] = (df['bike_docks_per_area'] - df['bike_docks_per_area'].min()) / (
            df['bike_docks_per_area'].max() - df['bike_docks_per_area'].min())
    df['transportation_per_area'] = (df['bus_stations_per_area'] * 0.7) + (
            df['bike_docks_per_area'] * 0.3)
    df['restaurants_per_area'] = (df['restaurants_per_area'] - df[
        'restaurants_per_area'].min()) / (df['restaurants_per_area'].max() - df['restaurants_per_area'].min())
    # print(df['restaurants_per_area'].max())
    # print(df)
    df.to_csv('normalized_zipcode.csv', index=False)
    return df


def download_new_data():
    # If needed, download datasets by calling download_data()
    download_data()

    # Load dataset into variables.
    # If needed, convert datasets latitude and longitude to zipcode(takes more than 1.5 hrs) by calling
    # write_crime_zipcode(), write_bus_zipcode(),write_bike_zipcode(); write_crime_zipcode().
    crime_data = load_crime("crime_incident_data.csv")
    bus_data = load_bus("bus_data.txt")
    bike_data = load_bike("bike_data.csv")

    crime_data = write_crime_zipcode(crime_data)
    bus_data = write_bus_zipcode(bus_data)
    bike_data = write_bike_zipcode(bike_data)

    # Recommender Algorithms
    info_based_on_zipcode = aggregate_zipcode(crime_data, bus_data, bike_data)
    result_df = compute_metrics_per_area('boston_zipcodes.geojson', info_based_on_zipcode)
    normalize_dataframe(result_df)
    create_visualizations()


def use_processed_data():
    # Otherwise, use converted csv files directly with following three commands.
    crime_data = pd.read_csv("crime_incident_data_with_zipcode.csv", index_col=0, dtype={'zipcode': str})
    bus_data = pd.read_csv("bus_data_with_zipcode.csv", index_col=0, dtype={'zipcode': str})
    bike_data = pd.read_csv("bike_data_with_zipcode.csv", index_col=0, dtype={'zipcode': str})

    # Recommender Algorithms
    info_based_on_zipcode = aggregate_zipcode(crime_data, bus_data, bike_data)
    result_df = compute_metrics_per_area('boston_zipcodes.geojson', info_based_on_zipcode)
    normalize_dataframe(result_df)
    create_visualizations()


def create_visualizations():
    visualize_restaurants.create_restaurant_visualization()
    visualize_Transportation.create_transportation_visualization()
    visualize_crimes.create_crime_visualization()


def count_hotel():
    hres = {}
    hotels = csv.reader(open("old_hotels.csv", "r", encoding="utf-8"))
    for row in hotels:
        zc = "0{}".format(str(row[3][:4]))
        if zc in hres:
            hres[zc] += 1
        else:
            hres[zc] = 1

    output = csv.writer(open("hotel_count.csv", "w", encoding="utf-8", newline=""))
    for key, val in hres.items():
        output.writerow([str(key), val])

# if __name__ == "__main__":
# download_data()
# use_downloaded()
