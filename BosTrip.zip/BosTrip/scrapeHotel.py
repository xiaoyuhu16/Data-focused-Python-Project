# Name: Xiaoyu Hu, Yang Wang, Han Bao, Zhenyi Wei, Wei Zou
# Andrew ID: xiaoyuhu, yangwan4, hanb, zhenyiw, weizou
# This scrapeHotel.py is imported in data_processing.py

import os
import requests
import csv
import json
from bs4 import BeautifulSoup
import http.client


conn = http.client.HTTPSConnection("www.booking.com")
payload = ''
headers = {
  'Cookie': '_pxhd=I4Vm2AGuKmZhMoLrNUmxycO6SwsfMSFCV7dVlBngiN5jI8VjLMhj0I7I5GIDvSMmT9A-y8-7Ik8JF6-qgFBowQ%253D%253D%253AcaViv%252FW901xhUI-3Aqa06kcjdH8gk3DF%252FSthfgoME7z-p5kkg75ROI4xONS%252FEIO18zz7CRRVfb4sJf4dfeHeUkOcwkho7yiW30eU5uVLrHE%253D; bkng=11UmFuZG9tSVYkc2RlIyh9Yaa29%2F3xUOLbA1O770KQL%2BynQDWDn1fNAixAkEgJwmN83O1MoCdvDyf%2FmlJejCciNDJX2cwbTeOSZkdZZebXx7tR0v0eXzXO4D%2F2ZjjKmNria1HIfb2ZpxJ5Sp4%2FwBAso4ozA%2B%2Ff4JYrCIGAEhC%2FMDdFPfpEVs5jtRLWi4YMECPTJFdqCobymt7iMnC%2FLKdktLEWtDaPAYNDc7p75iC8RkpzlBLW2jmV%2F1cPrYWSZKnp; bkng_sso_auth=CAIQsOnuTRqUAe/fSPzQ5xnYTDr0uBDQBF+K6OsYIRKiNv3eAUACZj4pbhtIeazUTEMWc4/UzqcazkTGpkQSE6mS7Kgd9+osU47F0Km9OMDlT8UTg7u01UpA7z7PTj5B23MPZFQ3VkU2zBeMNZ28dfO04YapxUBYQapd+Xrcfpy3CDuvyg7SF7+w2jU2RPNYlYZYnIBQeiApZ8kD21Y=; pcm_consent=analytical%3Dtrue%26countryCode%3DUS%26consentId%3D91df4980-a2cd-4107-9de4-8b88f5ef64c3%26consentedAt%3D2023-10-13T03%3A14%3A24.437Z%26expiresAt%3D2024-04-10T03%3A14%3A24.437Z%26implicit%3Dtrue%26marketing%3Dtrue%26regulation%3Dnone%26legacyRegulation%3Dnone; px_init=0'
}

dateList = [["2024-03-03", "2024-03-10"], ["2024-05-01", "2024-05-11"], ["2024-06-09", "2024-06-15"]]
# dateList = [["2024-03-03", "2024-03-10"]]

def singlePage(checkin, checkout, offset):
    reslinks = set()
    try:
        conn.request("GET", "/searchresults.html?group_adults=2&sb=1&ssne_untouched=Boston&src_elem=sb&aid=2311236&no_rooms=1&efdco=1&lang=en-us&dest_id=20061717&ss=Boston&dest_type=city&checkin={}&ssne=Boston&src=searchresults&checkout={}&offset={}&sid=2c6d9880538b0859fd5bf3e4adcbce0f&group_children=0".format(checkin, checkout, offset), payload, headers)
        res = conn.getresponse()
        data = res.read().decode("utf-8")
        print("Downloading Page {}".format(offset / 25 + 1))

        soup = BeautifulSoup(data, "lxml")
        atags = soup.find_all("a")
        for atag in atags:
            if not atag.has_attr("href"):
                continue
            link = atag.get("href")
            if not link.startswith("https://www.booking.com/hotel/us"):
                continue
            reslinks.add(link)
        return reslinks
    except Exception as e:
        print(e)
        return reslinks


def getLinks(dates = dateList):
    hotelTag = set()
    finalLinks = set()
    for offset in range(0, 250, 25):
        for date in dates:
            res = singlePage(date[0], date[1], offset)
            for link in res:
                hotelTitle = link.split("?")[0]
                if hotelTitle in hotelTag:
                    continue
                hotelTag.add(hotelTitle)
                finalLinks.add(link)
            print("Get {} Hotels.".format(len(finalLinks)))
    # open("links.txt", "w", encoding = "utf-8").write("\n".join(finalLinks))
    return finalLinks
    

def getHotelLinks(text):
    res = set()
    page = BeautifulSoup(text, "lxml")
    for atag in page.find_all('a'):
        href = atag['href']
        if href.startswith("https://www.booking.com/hotel/us"):
            res.add(href)
    return res


def getList(outputFile):
    csv_writer = csv.writer(open("raw_{}".format(outputFile), "w", encoding = "utf-8", newline = ""))
    res = set()
    # for i in range(9):
    #     print("--> Extracting Hotels From Page {}".format(i + 1))
    #     text = open("hotelList/hotel_list{}.txt".format(i), "r", encoding = "utf-8").read()
    #     for link in getHotelLinks(text):
    #         res.add(link)
    res = getLinks()
    hotels = []
    for singleHotel in res:
        resp = requests.get(singleHotel).text
        row = extractInfo(resp)
        hotels.append(row)
        print("--> --> Scraping Hotel {}".format(row[0]))
        csv_writer.writerow(row)
    # sort
    csv_writer = csv.writer(open(outputFile, "w", encoding = "utf-8", newline = ""))
    hotels = [_[:8] + [float(_[8])] + _[9:] if _[8] else _[:8] + [0] + _[9:] for _ in hotels]
    hotels.sort(key = lambda k : k[8], reverse = True)
    for row in hotels:
        csv_writer.writerow(row)
    

def getScript(soup):
    try:
        script = soup.find("script", {"type": "application/ld+json"})
        script = str(script)
        script = json.loads(script[script.find("{") : script.find("</script>")])
    except:
        script = {}
    return script


def getTitle(soup):
    ### get title : <title>citizenM Boston North Station, Boston – Updated 2023 Prices</title>
    try:
        title = soup.find("title").text.split(", Boston")[0]
    except:
        title = ""
    return title


def getDis(soup):
    ### get distance from cener # is 1 mile from the centre
    try:
        mile = ""
        mileSoup = soup.find_all("div", itemprop = "text")
        for tmp in mileSoup:
            if tmp.find('p') and 'from the center' in tmp.find('p').text:
                mile = tmp.find('p').text.split(' from the center ')[0].split("is ")[1]
    except:
        mile = ""
    return mile
    

def getAdd(soup):
    ### get Address and latitude longtitude
    try:
        address = soup.find("span", class_ = "hp_address_subtitle js-hp_address_subtitle jq_tooltip")
        lat1, long1, lat2, long2 = address['data-bbox'].split(",")
        addText = address.text
        zipcode = str(addText.split(", Boston, ")[1].split(",")[0].replace("MA", ""))
        if len(zipcode) == 4:
            zipcode = "0" + zipcode
        zipcode = "MA " + zipcode
    except:
        addText = ""
        zipcode = "MA 00000"
        lat1, long1, lat2, long2 = ("", "", "", "")
    return lat1, long1, lat2, long2, addText, zipcode


def getRating(script):
    ### get rating value
    try:
        rating = script["aggregateRating"]["ratingValue"]
    except:
        rating = ""
    return rating


def getPrice(script):
    ### get prices
    try:
        price = script['priceRange'].split("$")[1].split(" ")[0]
    except:
        price = ""
    return price


def getUrl(script):
    ### url
    try:
        url = script['url']
    except:
        url = ""
    return url


def getSubway(text):
    ### subway access
    subway_acc = 'No'
    if "Subway Access" in text:
        subway_acc = 'Yes'
    return subway_acc
    

def extractInfo(text):
    soup = BeautifulSoup(text, "lxml")
    script = getScript(soup)
    title = getTitle(soup)
    mile = getDis(soup)
    lat1, long1, lat2, long2, addText, zipcode = getAdd(soup)
    rating = getRating(script)
    price = getPrice(script)
    url = getUrl(script)
    subway_acc = getSubway(text)
    return [title, mile, addText, zipcode, lat1, long1, lat2, long2, rating, price, subway_acc, url]
    

if __name__ == "__main__":
    getList("hotels.csv")