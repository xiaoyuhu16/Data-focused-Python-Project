# Name: Xiaoyu Hu, Yang Wang, Han Bao, Zhenyi Wei, Wei Zou
# Andrew ID: xiaoyuhu, yangwan4, hanb, zhenyiw, weizou
# This visualization module is imported in data_processing.py

import pandas as pd
import folium
import json


# import pdfkit

def create_restaurant_visualization():
    # Read the data
    df = pd.read_csv("restaurants.csv", dtype=str)
    df.columns = ['Name', 'Type', 'Price', 'Website', 'Price Range', 'Location', 'Rating',
                  'Food Category', 'Latitude', 'Longitude', 'Address', 'Address2', 'phone_number']
    df['Latitude'] = pd.to_numeric(df['Latitude'])
    df['Longitude'] = pd.to_numeric(df['Longitude'])
    # Initialize a map centered around Boston
    m = folium.Map(location=[42.3601, -71.0589], zoom_start=13)  # Coordinates for Boston's center

    # Add a marker for each restaurant
    for _, row in df.iterrows():
        folium.Marker(
            location=[row['Latitude'], row['Longitude']],
            popup=row['Name'],
            icon=folium.Icon(icon="cutlery", prefix="fa")  # Using a fork-and-knife icon from Font Awesome
        ).add_to(m)

    # Add ZIP code boundaries to the map
    geojson_path = "boston_zipcodes.geojson"
    with open(geojson_path, 'r') as file:
        zipcodes_geojson = json.load(file)

    folium.GeoJson(
        zipcodes_geojson,
        name='ZIP Code Boundaries',
        style_function=lambda x: {
            'fillColor': 'transparent',
            'color': 'blue',
            'weight': 1.5,
            'fillOpacity': 0
        }
    ).add_to(m)
    # Save the map as HTML first
    html_path = "boston_restaurants.html"
    m.save(html_path)

    # Convert the HTML to PDF
    """pdf_path = "boston_restaurants.pdf"
    pdfkit.from_file(html_path, pdf_path)"""


# create_restaurant_visualization()
