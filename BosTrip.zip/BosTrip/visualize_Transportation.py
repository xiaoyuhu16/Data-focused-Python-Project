# Name: Xiaoyu Hu, Yang Wang, Han Bao, Zhenyi Wei, Wei Zou
# Andrew ID: xiaoyuhu, yangwan4, hanb, zhenyiw, weizou
# This visualization module is imported in data_processing.py

import pandas as pd
import folium
import json

def create_transportation_visualization():
    #  bike stations
    df_bike = pd.read_csv("bike_data_with_zipcode.csv")

    # bus stops
    df_bus = pd.read_csv("bus_data_with_zipcode.csv")

    # Create a map
    m = folium.Map(location=[42.3601, -71.0589], zoom_start=13)

    # Add bike station to the map
    for _, row in df_bike.iterrows():
        folium.CircleMarker(
            location=[row['Latitude'], row['Longitude']],
            radius=row['Total docks'] / 2,  # Adjust the division factor to get a suitable size
            fill=True,
            fill_color='blue' if row['Total docks'] > 15 else 'lightblue',
            color='blue',
            fill_opacity=0.6
        ).add_to(m)

    # Add bus stop to the map
    for _, row in df_bus.iterrows():
        folium.Marker(
            location=[row['Latitude'], row['Longitude']],
            popup=row['STOP_NAME'],
            icon=folium.Icon(color="red", icon="bus", prefix="fa")  # bus icon for bus stop
        ).add_to(m)

    # Add ZIP code boundaries to the map
    geojson_path = "boston_zipcodes.geojson"
    with open(geojson_path, 'r') as file:
        zipcodes_geojson = json.load(file)

    folium.GeoJson(
        zipcodes_geojson,
        name='ZIP Code Boundaries',
        style_function=lambda x: {
            'fillColor': 'transparent',
            'color': 'blue',
            'weight': 1.5,
            'fillOpacity': 0
        }
    ).add_to(m)

    # save the map
    m.save("boston_transport_map.html")